package com.example.student.evaluation2;

import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        CoordinatorLayout activity=(CoordinatorLayout)findViewById(R.id.activity_main2);

        Intent intent=getIntent();
        int pencil=intent.getIntExtra("pencil",0);

        if (pencil==1)
            activity.setBackgroundColor(Color.parseColor("#FF0000"));
        if (pencil==2)
            activity.setBackgroundColor(Color.parseColor("#008000"));
        if (pencil==3)
            activity.setBackgroundColor(Color.parseColor("#0000FF"));
    }
}
