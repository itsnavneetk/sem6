package com.example.student.evaluation2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView pencil1=(ImageView)findViewById(R.id.pencil1);
        ImageView pencil2=(ImageView)findViewById(R.id.pencil2);
        ImageView pencil3=(ImageView)findViewById(R.id.pencil3);

        pencil1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), Main2Activity.class);
                intent.putExtra("pencil", 1);
                startActivity(intent);
            }
        });

        pencil2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), Main2Activity.class);
                intent.putExtra("pencil", 2);
                startActivity(intent);
            }
        });

        pencil3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), Main2Activity.class);
                intent.putExtra("pencil", 3);
                startActivity(intent);
            }
        });
    }
}
