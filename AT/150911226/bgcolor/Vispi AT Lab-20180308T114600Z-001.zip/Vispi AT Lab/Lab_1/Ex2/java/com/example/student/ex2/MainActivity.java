package com.example.student.ex2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button=(Button)findViewById(R.id.button);
        final EditText email=(EditText)findViewById(R.id.email);
        final EditText mobile=(EditText)findViewById(R.id.mobile);
        final EditText password=(EditText)findViewById(R.id.password);
        final TextView emailAlert=(TextView)findViewById(R.id.emailAlert);
        final TextView mobileAlert=(TextView)findViewById(R.id.mobileAlert);

        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String s1=s.toString();
                if (!s1.contains("@"))
                    emailAlert.setText("!");
                else
                    emailAlert.setText("");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mobile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                String s1=s.toString();
                if (s1.length()!=10)
                    mobileAlert.setText("!");
                else
                    mobileAlert.setText("");
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email.setText("");
                emailAlert.setText("");
                mobile.setText("");
                mobileAlert.setText("");
                password.setText("");

                Toast.makeText(getApplicationContext(), "Thank You for your submission!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
