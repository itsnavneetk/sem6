package com.example.student.ex3;

import android.graphics.Color;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadioButton radioRed=(RadioButton)findViewById(R.id.radioRed);
        RadioButton radioGreen=(RadioButton)findViewById(R.id.radioGreen);
        RadioButton radioBlue=(RadioButton)findViewById(R.id.radioBlue);
        RadioButton radioYellow=(RadioButton)findViewById(R.id.radioYellow);
        RadioButton radioBlack=(RadioButton)findViewById(R.id.radioBlack);
        RadioButton radioWhite=(RadioButton)findViewById(R.id.radioWhite);
        RadioButton radioOrange=(RadioButton)findViewById(R.id.radioOrange);

        final CoordinatorLayout c=(CoordinatorLayout)findViewById(R.id.activity_main);

        radioRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.setBackgroundColor(Color.parseColor("#F44336"));
            }
        });

        radioGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.setBackgroundColor(Color.parseColor("#4CAF50"));
            }
        });

        radioBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.setBackgroundColor(Color.parseColor("#2196F3"));
            }
        });

        radioYellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.setBackgroundColor(Color.parseColor("#FBC02D"));
            }
        });

        radioBlack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.setBackgroundColor(Color.parseColor("#000000"));
            }
        });

        radioWhite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.setBackgroundColor(Color.parseColor("#FFFFFF"));
            }
        });

        radioOrange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c.setBackgroundColor(Color.parseColor("#FFB74D"));
            }
        });
    }
}
