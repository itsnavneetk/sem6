package com.example.mahe.testapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    float op1;
    String opr;
    boolean resJust=false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView res=(TextView)findViewById(R.id.res);

        TextView num0=(TextView)findViewById(R.id.num0);
        num0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("0");
                else
                    res.setText(cur+"0");

                resJust=false;
            }
        });

        TextView num1=(TextView)findViewById(R.id.num1);
        num1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("1");
                else
                    res.setText(cur+"1");

                resJust=false;
            }
        });

        TextView num2=(TextView)findViewById(R.id.num2);
        num2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("2");
                else
                    res.setText(cur+"2");

                resJust=false;
            }
        });

        TextView num3=(TextView)findViewById(R.id.num3);
        num3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("3");
                else
                    res.setText(cur+"3");

                resJust=false;
            }
        });

        TextView num4=(TextView)findViewById(R.id.num4);
        num4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("4");
                else
                    res.setText(cur+"4");

                resJust=false;
            }
        });

        TextView num5=(TextView)findViewById(R.id.num5);
        num5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("5");
                else
                    res.setText(cur+"5");

                resJust=false;
            }
        });

        TextView num6=(TextView)findViewById(R.id.num6);
        num6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("6");
                else
                    res.setText(cur+"6");

                resJust=false;
            }
        });

        TextView num7=(TextView)findViewById(R.id.num7);
        num7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("7");
                else
                    res.setText(cur+"7");

                resJust=false;
            }
        });

        TextView num8=(TextView)findViewById(R.id.num8);
        num8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("8");
                else
                    res.setText(cur+"8");

                resJust=false;
            }
        });

        TextView num9=(TextView)findViewById(R.id.num9);
        num9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (cur.equals("0") || cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || resJust)
                    res.setText("9");
                else
                    res.setText(cur+"9");

                resJust=false;
            }
        });

        TextView dec=(TextView)findViewById(R.id.dec);
        dec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (!(cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/") || cur.contains(".")))
                    res.setText(cur+".");
            }
        });


        TextView plus=(TextView)findViewById(R.id.plus);
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (!(cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/")))
                {
                    if (op1==0)
                        op1=Float.parseFloat(cur);
                    else
                        op1=op1+Float.parseFloat(cur);
                }
                opr="+";
                res.setText(opr);
            }
        });

        TextView minus=(TextView)findViewById(R.id.minus);
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (!(cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/")))
                {
                    if (op1==0)
                        op1=Float.parseFloat(cur);
                    else
                        op1=op1-Float.parseFloat(cur);
                }
                opr="-";
                res.setText(opr);
            }
        });

        TextView mul=(TextView)findViewById(R.id.mul);
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (!(cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/")))
                {
                    if (op1==0)
                        op1=Float.parseFloat(cur);
                    else
                        op1=op1*Float.parseFloat(cur);
                }
                opr="*";
                res.setText(opr);
            }
        });

        TextView div=(TextView)findViewById(R.id.div);
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (!(cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/")))
                {
                    if (op1==0)
                        op1=Float.parseFloat(cur);
                    else
                        op1=op1/Float.parseFloat(cur);
                }
                opr="/";
                res.setText(opr);
            }
        });

        TextView equals=(TextView)findViewById(R.id.equals);
        equals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (!(cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/")))
                {
                    if (op1==0)
                        op1=Float.parseFloat(cur);
                    else
                    {
                        if (opr.equals("+"))
                            op1 = op1 + Float.parseFloat(cur);
                        else if (opr.equals("-"))
                            op1 = op1 - Float.parseFloat(cur);
                        else if (opr.equals("*"))
                            op1 = op1 * Float.parseFloat(cur);
                        else if (opr.equals("/"))
                            op1 = op1 / Float.parseFloat(cur);
                    }
                }
                opr="+";
                res.setText(Float.toString(op1));
                op1=0;
                resJust=true;
            }
        });

        TextView ac=(TextView)findViewById(R.id.ac);
        ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                res.setText("0");
                op1=0;
                opr="+";
            }
        });

        TextView del=(TextView)findViewById(R.id.del);
        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cur=res.getText().toString();
                if (!(cur.equals("+")||cur.equals("-")||cur.equals("*")||cur.equals("/")))
                {
                    if (cur.length()==1)
                        res.setText("0");
                    else
                        res.setText(cur.substring(0, cur.length()-1));
                }
            }
        });
    }


}
