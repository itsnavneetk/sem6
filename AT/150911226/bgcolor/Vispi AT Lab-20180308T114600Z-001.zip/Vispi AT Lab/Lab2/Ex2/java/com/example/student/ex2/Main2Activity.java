package com.example.student.ex2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {


    protected String encrypt(String value)
    {

        String encStr="";

        for (int i=0; i<value.length(); i++)
            encStr+=Character.toString((char)(value.charAt(i)-4));

        return encStr;
    }

    protected String decrypt(String value)
    {

        String encStr="";

        for (int i=0; i<value.length(); i++)
            encStr+=Character.toString((char)(value.charAt(i)+4));

        return encStr;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent=getIntent();
        String value=intent.getStringExtra("vispiValue");

        final EditText dec=(EditText)findViewById(R.id.encryptText);
        dec.setText(encrypt(value));

        final TextView decText=(TextView)findViewById(R.id.decryptText);

        Button button=(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decText.setText("Decrypted Value: "+decrypt(dec.getText().toString()));
            }
        });
    }
}
