package com.example.student.ex1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView printText=(TextView)findViewById(R.id.printText);

        final ArrayList<String> groceriesList=new ArrayList<>();
        groceriesList.add("Papeta");
        groceriesList.add("Tomota");
        groceriesList.add("Khaan");
        groceriesList.add("Meethu");
        groceriesList.add("Kaanda");
        groceriesList.add("Bheeda");
        groceriesList.add("Eeda");
        
        ArrayAdapter<String> groceriesAdapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, groceriesList);
        
        ListView groceries=(ListView)findViewById(R.id.groceriesList);
        groceries.setAdapter(groceriesAdapter);


        groceries.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                printText.setText(groceriesList.get(i));
                Toast.makeText(getApplicationContext(), groceriesList.get(i), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
