package com.example.mahe.testapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class QuizScreen extends AppCompatActivity {

    ArrayList<ArrayList<String>> questionsList;
    ArrayList<Integer> askedQs;

    TextView questionsText;
    RadioButton option1;
    RadioButton option2;
    RadioButton option3;
    RadioButton option4;
    TextView resultText;

    RadioGroup radioGroup;

    TextView scoreText;

    Button nextButton;

    String answer;

    boolean resumed=false;

    @Override
    protected void onResume()
    {
        super.onResume();

        if (resumed)
            onBackPressed();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_screen);



        questionsText=(TextView)findViewById(R.id.questionText);
        option1=(RadioButton)findViewById(R.id.option1);
        option2=(RadioButton)findViewById(R.id.option2);
        option3=(RadioButton)findViewById(R.id.option3);
        option4=(RadioButton)findViewById(R.id.option4);
        resultText=(TextView)findViewById(R.id.resultText);

        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);

        scoreText=(TextView)findViewById(R.id.scoreText);

        questionsList=new ArrayList<>();

        ArrayList<String> q1=new ArrayList<>();
        q1.add("Electric bulb filament is made of:");
        q1.add("Copper");
        q1.add("Lead");
        q1.add("Aluminium");
        q1.add("Tungsten");
        q1.add("Tungsten");
        questionsList.add(q1);

        ArrayList<String> q2=new ArrayList<>();
        q2.add("Which of the following is used in pencils?");
        q2.add("Graphite");
        q2.add("Silicon");
        q2.add("Charcoal");
        q2.add("Phosphorous");
        q2.add("Graphite");
        questionsList.add(q2);

        ArrayList<String> q3=new ArrayList<>();
        q3.add("The gas usually filled in the electric bulb is:");
        q3.add("Nitrogen");
        q3.add("Hydrogen");
        q3.add("Carbon dioxide");
        q3.add("Oxygen");
        q3.add("Nitrogen");
        questionsList.add(q3);

        ArrayList<String> q4=new ArrayList<>();
        q4.add("Quartz crystals, normally used in quartz clocks, are chemically:");
        q4.add("Silicon Dioxide");
        q4.add("Germanium Oxide");
        q4.add("A mixture of Germanium Oxide and Silicon dioxide");
        q4.add("Sodium Silicate");
        q4.add("Silicon Dioxide");
        questionsList.add(q4);

        ArrayList<String> q5=new ArrayList<>();
        q5.add("Bromine is a:");
        q5.add("Black Solid");
        q5.add("Red Liquid");
        q5.add("Colourless Gas");
        q5.add("Highly Inflammable Gas");
        q5.add("Black Solid");
        questionsList.add(q5);

        ArrayList<String> q6=new ArrayList<>();
        q6.add("The inert gas which is substituted for nitrogen in the air used by deep sea divers for breathing, is:");
        q6.add("Argon");
        q6.add("Xenon");
        q6.add("Helium");
        q6.add("Krypton");
        q6.add("Helium");
        questionsList.add(q6);

        ArrayList<String> q7=new ArrayList<>();
        q7.add("Garampani sanctuary is located in:");
        q7.add("Gangtok, Sikkim");
        q7.add("Kohima, Nagaland");
        q7.add("Diphu, Assam");
        q7.add("Junagarh, Gujarat");
        q7.add("Diphu, Assam");
        questionsList.add(q7);

        ArrayList<String> q8=new ArrayList<>();
        q8.add("Golf player Vijay Singh belongs to which country?");
        q8.add("India");
        q8.add("Fiji");
        q8.add("UK");
        q8.add("USA");
        q8.add("Fiji");
        questionsList.add(q8);

        ArrayList<String> q9=new ArrayList<>();
        q9.add("In the Harry Potter series, what was James Potter's nickname?");
        q9.add("Moony");
        q9.add("Wormtail");
        q9.add("Padfoot");
        q9.add("Prongs");
        q9.add("Prongs");
        questionsList.add(q9);

        ArrayList<String> q10=new ArrayList<>();
        q10.add("In the Harry Potter series, how was Marvolo related to Voldemort?");
        q10.add("His father");
        q10.add("His father's father");
        q10.add("His mother's father");
        q10.add("Unrelated");
        q10.add("His mother's father");
        questionsList.add(q10);


        askedQs=new ArrayList<>();

        nextButton=(Button)findViewById(R.id.nextButton);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (askedQs.size()<5)
                    setQuestion();
                else
                {
                    resumed=true;

                    Intent intent=new Intent(getApplicationContext(), ResultPage.class);
                    intent.putExtra("vispiScore", scoreText.getText().toString());
                    startActivity(intent);
                }

            }
        });

        option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer(option1.getText().toString());
            }
        });

        option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer(option2.getText().toString());
            }
        });

        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer(option3.getText().toString());
            }
        });

        option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswer(option4.getText().toString());
            }
        });


        setQuestion();

    }

    protected void checkAnswer(String subAns)
    {
        if (subAns.equals(answer))
        {
            resultText.setText("Correct!");
            resultText.setTextColor(Color.parseColor("#4CAF50"));

            int currScore= Integer.parseInt(scoreText.getText().toString());
            scoreText.setText(Integer.toString(currScore+1));
        }
        else
        {
            resultText.setText("Wrong!");
            resultText.setTextColor(Color.RED);
        }

        option1.setEnabled(false);
        option2.setEnabled(false);
        option3.setEnabled(false);
        option4.setEnabled(false);

        if (option1.getText().toString().equals(answer))
            option1.setTextColor(Color.parseColor("#4CAF50"));
        if (option2.getText().toString().equals(answer))
            option2.setTextColor(Color.parseColor("#4CAF50"));
        if (option3.getText().toString().equals(answer))
            option3.setTextColor(Color.parseColor("#4CAF50"));
        if (option4.getText().toString().equals(answer))
            option4.setTextColor(Color.parseColor("#4CAF50"));

        if (askedQs.size()==5)
        {
            nextButton.setText("Finish");

            AlertDialog.Builder endAlert;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                endAlert = new AlertDialog.Builder(QuizScreen.this, android.R.style.Theme_Material_Light_Dialog_Alert);
            else
                endAlert = new AlertDialog.Builder(QuizScreen.this);

            endAlert.setTitle("End of Quiz");
            endAlert.setIcon(R.drawable.caution);
            endAlert.setMessage("You have reached the last question of the quiz. Thank you for playing!");

            endAlert.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });

            endAlert.setCancelable(false);

            endAlert.show();
        }
    }

    protected void setQuestion()
    {
        resultText.setText("");

        radioGroup.clearCheck();
        option1.setEnabled(true);
        option2.setEnabled(true);
        option3.setEnabled(true);
        option4.setEnabled(true);

        option1.setTextColor(Color.BLACK);
        option2.setTextColor(Color.BLACK);
        option3.setTextColor(Color.BLACK);
        option4.setTextColor(Color.BLACK);

        int qNo;
        while(true)
        {
            qNo=(int)(Math.random()*questionsList.size());
            if (!askedQs.contains(qNo))
                break;
        }
        askedQs.add(qNo);

        ArrayList currQ=questionsList.get(qNo);
        questionsText.setText(Integer.toString(askedQs.size())+". "+currQ.get(0).toString());

        ArrayList<Integer> addedOpt=new ArrayList<>();
        int opNo;

        while (true)
        {
            opNo=(int)Math.ceil(Math.random()*4);
            if (!addedOpt.contains(opNo))
                break;
        }
        addedOpt.add(opNo);
        option1.setText(currQ.get(opNo).toString());

        while (true)
        {
            opNo=(int)Math.ceil(Math.random()*4);
            if (!addedOpt.contains(opNo))
                break;
        }
        addedOpt.add(opNo);
        option2.setText(currQ.get(opNo).toString());

        while (true)
        {
            opNo=(int)Math.ceil(Math.random()*4);
            if (!addedOpt.contains(opNo))
                break;
        }
        addedOpt.add(opNo);
        option3.setText(currQ.get(opNo).toString());

        while (true)
        {
            opNo=(int)Math.ceil(Math.random()*4);
            if (!addedOpt.contains(opNo))
                break;
        }
        addedOpt.add(opNo);
        option4.setText(currQ.get(opNo).toString());

        answer=currQ.get(5).toString();
    }
}
