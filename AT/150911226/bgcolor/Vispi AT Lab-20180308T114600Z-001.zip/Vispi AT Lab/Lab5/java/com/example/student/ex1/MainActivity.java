package com.example.student.ex1;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {


    boolean paused=false;
    boolean stopped=true;

    TextView curTime;
    TextView totTime;
    SeekBar seekBar;

    ImageView rewind;
    ImageView pause;
    ImageView forward;
    ImageView play;

    MediaPlayer rude;


    double currentTime=0;

     Handler handler=new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        curTime=(TextView)findViewById(R.id.curTimeText);
        totTime=(TextView)findViewById(R.id.totTimeText);
        seekBar=(SeekBar)findViewById(R.id.seekBar);

        rewind=(ImageView)findViewById(R.id.rewindButton);
        pause=(ImageView)findViewById(R.id.pauseButton);
        forward=(ImageView)findViewById(R.id.forwardButton);
        play=(ImageView)findViewById(R.id.playButton);

        rude=MediaPlayer.create(this,R.raw.rude);

        final int totTimeD=rude.getDuration();
        totTime.setText(String.format("%d:%d",
                TimeUnit.MILLISECONDS.toMinutes((long)totTimeD),
                TimeUnit.MILLISECONDS.toSeconds((long)totTimeD)-
                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long)totTimeD)))
        );

        seekBar.setMax(totTimeD);

        seekBar.setProgress((int)currentTime);
        handler.postDelayed(updateSongTime,100);

        rude.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                rude.seekTo(0);
                currentTime=0;
                stopped=true;
                paused=false;
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                currentTime=progress;
                rude.seekTo((int)currentTime);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        rewind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!paused && !stopped)
                {
                    if (currentTime - 5000 > 0)
                        currentTime -= 5000;
                    else
                        currentTime = 0;
                }

                rude.seekTo((int)currentTime);
            }
        });

        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!paused && !stopped)
                {
                    rude.pause();
                    paused=true;
                }

            }
        });

        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!paused && !stopped)
                {
                    if (currentTime + 5000 < totTimeD)
                        currentTime += 5000;
                    else
                        currentTime = totTimeD;
                }

                rude.seekTo((int)currentTime);
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (stopped)
                {
                    currentTime=0;
                    rude.start();
                    stopped=false;
                }
                else if (paused)
                {
                    rude.start();
                    paused=false;
                }
            }
        });

    }

    protected Runnable updateSongTime=new Runnable() {
        @Override
        public void run() {
            currentTime=rude.getCurrentPosition();
            curTime.setText(String.format("%d:%d",
                    TimeUnit.MILLISECONDS.toMinutes((long)currentTime),
                    TimeUnit.MILLISECONDS.toSeconds((long)currentTime)-
                    TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes((long)currentTime)))
            );
            seekBar.setProgress((int)currentTime);
            handler.postDelayed(this,100);
        }
    };
}
