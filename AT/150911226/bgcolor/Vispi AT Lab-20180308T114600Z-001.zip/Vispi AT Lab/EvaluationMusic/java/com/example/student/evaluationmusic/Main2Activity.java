package com.example.student.evaluationmusic;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    MediaPlayer song;

    TextView currTimeText;
    TextView totTimeText;

    SeekBar seekBar;

    int currentTime;

    Handler handler;


    int option;


    Button rewindButton;
    Button playButton;
    Button forwardButton;





    protected Runnable setCurrTime=new Runnable() {
        @Override
        public void run() {


            currentTime=song.getCurrentPosition();

//            long mins=TimeUnit.MILLISECONDS.toMinutes((long)currentTime);
//            long secs=TimeUnit.MILLISECONDS.toSeconds((long)currentTime)-TimeUnit.MILLISECONDS.toMinutes((long)currentTime)*60;
//
//            String minsS=Long.toString(mins);
//            String secsS=Long.toString(secs);
//            if (secsS.length()==1)
//                secsS="0"+secsS;
//
//            currTimeText.setText(minsS+":"+secsS);

            if (option==0)
                currTimeText.setText(Integer.toString(currentTime)+" ms");

            seekBar.setProgress(currentTime);
            handler.postDelayed(this,1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        Intent intent=getIntent();
        option=intent.getIntExtra("vispiOption",0);

        song=MediaPlayer.create(getApplicationContext(),R.raw.song);

        currTimeText=(TextView)findViewById(R.id.currTime);
        totTimeText=(TextView)findViewById(R.id.totTime);

        seekBar=(SeekBar)findViewById(R.id.seekBar);

        final int totTimeInt=song.getDuration();

        seekBar.setMax(totTimeInt);

//        long mins=TimeUnit.MILLISECONDS.toMinutes((long)totTimeInt);
//        long secs=TimeUnit.MILLISECONDS.toSeconds((long)totTimeInt)-TimeUnit.MILLISECONDS.toMinutes((long)totTimeInt)*60;
//
//        String minsS=Long.toString(mins);
//        String secsS=Long.toString(secs);
//        if (secsS.length()==1)
//            secsS="0"+secsS;
//
//        totTimeText.setText(minsS+":"+secsS);

        if (option==0)
            totTimeText.setText(Integer.toString(totTimeInt)+" ms");
        else
        {
            totTimeText.setText("");
            currTimeText.setText("");
        }

        handler=new Handler();
        handler.postDelayed(setCurrTime,1000);


        rewindButton=(Button)findViewById(R.id.rewindButton);
        playButton=(Button)findViewById(R.id.playButton);
        forwardButton=(Button)findViewById(R.id.forwardButton);


        rewindButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (currentTime-5000>0)
                {
                    currentTime-=5000;
                    song.seekTo(currentTime);
                }
                else
                    song.seekTo(0);
            }
        });

        forwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (currentTime+5000<totTimeInt)
                {
                    currentTime+=5000;
                    song.seekTo(currentTime);
                }
                else
                    song.seekTo(totTimeInt);
            }
        });


        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                song.start();
            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                currentTime=progress;
                song.seekTo(currentTime);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        if (option==0)
        {
            rewindButton.setEnabled(false);
            forwardButton.setEnabled(false);
        }
        else
            seekBar.setEnabled(false);


    }


    @Override
    public void onBackPressed()
    {
        song.stop();
        super.onBackPressed();
    }

}

