package com.example.student.evaluationmusic;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView=(ListView)findViewById(R.id.listView);

        ArrayList<String> list=new ArrayList<>();
        list.add("SeekBar Control");
        list.add("Button Control");
        list.add("Close App");

        ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,list);

        listView.setAdapter(arrayAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                if (position==0 || position==1)
                {
                    Intent intent=new Intent(getApplicationContext(),Main2Activity.class);
                    intent.putExtra("vispiOption",position);
                    startActivity(intent);
                }
                else if (position==2)
                    onBackPressed();


            }
        });


    }
}
